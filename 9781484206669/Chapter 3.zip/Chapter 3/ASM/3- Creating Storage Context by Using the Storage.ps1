﻿##Generating Azure Storage Access Key (ASM)
$StorageAccountName = "mylabstroageaccount"
$StorageAccessKey = Get-AzureStorageKey -StorageAccountName $StorageAccountName | Select-ExpandProperty Primary

## Creating storage context using Storage Account Name and Key (ASM)
$StorageContext = New-AzureStorageContext –StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey