﻿#Authenticate to Azure Subscription
Add-AzureAccount

## Create new Azure storage account (ASM)
New-AzureStorageAccount -StorageAccountName mylabstorageaccount -Label "My Lab Storage" -Description "Cloud storage for Azure VMs" -Location "West Europe" 