﻿#Change Storage account replication option (ASM)
Set-AzureStorageAccount -StorageAccountName mylabstorageaccount -Type Standard_LRS