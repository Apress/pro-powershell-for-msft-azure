﻿# Publish RemoteApp Program - Google Chrome
Publish-AzureRemoteAppProgram -CollectionName col1 `
-FileVirtualPath "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" `
-DisplayName 'Google Chrome'