﻿## Create New Azure Traffic Manager Profile (ASM)

New-AzureTrafficManagerProfile `
-Name DevTestTM `
-DomainName 'DevTestLab.trafficmanager.net' `
-LoadBalancingMethod RoundRobin `
-MonitorProtocol Http `
-MonitorPort 80 `
-Ttl 30 `
-MonitorRelativePath '/'