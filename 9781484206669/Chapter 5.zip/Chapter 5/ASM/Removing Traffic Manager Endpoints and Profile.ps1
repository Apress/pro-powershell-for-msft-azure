﻿## Removing Endpoint to Traffic Manager Profile (ASM)

#Removing Traffic Manager EndPoints
$EP1 = 'website-ca.azurewebsites.net'
$EP2 = 'website-ea.azurewebsites.net'
$ATMP = Get-AzureTrafficManagerProfile -Name DevTestTM

Remove-AzureTrafficManagerEndpoint -TrafficManagerProfile $ATMP -DomainName $EP1

Remove-AzureTrafficManagerEndpoint -TrafficManagerProfile $ATMP -DomainName $EP2

Set-AzureTrafficManagerProfile -TrafficManagerProfile $ATMP

#Removing Traffic Manager Profile (ARM)
Remove-AzureTrafficManagerProfile –Name DevTestTM –ResourceGroupName DevTestRG -Force