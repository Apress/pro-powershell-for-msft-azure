﻿#Creating Network Security Group
$NSG = New-AzureNetworkSecurityGroup -Name 'DevTestNSG' -Location 'West Europe' -Label 'NSG for West Europe'

$NSG = Get-AzureNetworkSecurityGroup -Name "DevTestNSG"

$NSG | `
Set-AzureNetworkSecurityRule -Name rdp-access-rule ` 
-Action Allow ` 
-Protocol TCP `
-Type Inbound `
-Priority 100 `
-SourceAddressPrefix '10.0.1.0/24' `
-SourcePortRange '*' `
-DestinationAddressPrefix '*' `
-DestinationPortRange '3389'