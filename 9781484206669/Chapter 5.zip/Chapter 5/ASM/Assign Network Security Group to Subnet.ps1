﻿#Assign Network Security Group to Subnet (ASM)
$NSG = Get-AzureNetworkSecurityGroup -Name "DevTestNSG"

Set-AzureNetworkSecurityGroupToSubnet –NetworkSecurityGroup $NSG -VirtualNetworkName 'DevTestvNET' -SubnetName 'Internal'