﻿# Creating Azure VNet
Set-AzureVNetConfig -ConfigurationPath ./VNet.netcfg