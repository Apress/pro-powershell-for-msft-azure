﻿#Assign Network Security Group to VM (ASM)
$NSG = Get-AzureNetworkSecurityGroup -Name "DevTestNSG"

$VM = Get-AzureVM -ServiceName DevTest -Name VS2015

Set-AzureNetworkSecurityGroupConfig -NetworkSecurityGroupName "$NSG" –VM $VM | Update-AzureVM –VM $VM