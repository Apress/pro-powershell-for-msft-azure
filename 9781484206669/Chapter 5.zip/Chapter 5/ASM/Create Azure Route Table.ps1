﻿#Create Azure Route Table (ASM)
$RT = New-AzureRouteTable -Name DevTestRT -Location 'West Europe'

Set-AzureRoute `
-RouteName InternaltoFirewall `
-RouteTable $RT `
-AddressPrefix 10.0.0.0/24 `
-NextHopType VirtualAppliance `
-NextHopIpAddress 10.10.10.254

#Assign Route Tablet to Subnet (ASM)
Set-AzureSubnetRouteTable `
-VirtualNetworkName DevTestvNET `
-SubnetName Internal `
-RouteTableName DevTestRT

#Enable IP Forwarding on the Virtual Appliance VM (ASM)
Get-AzureVM -ServiceName DevTestFarm -Name WAP | Set-AzureIPForwarding –Enable