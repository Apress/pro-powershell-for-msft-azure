﻿## Adding Endpoint to Traffic Manager Profile (ASM)
$EP1 = 'website-ca.azurewebsites.net'
$EP2 = 'website-ea.azurewebsites.net'

$ATMP = Get-AzureTrafficManagerProfile -Name DevTestTM

Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $ATMP -DomainName $EP1 -Type AzureWebsite -Status Enabled

Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $ATMP -DomainName $EP2 -Type AzureWebsite -Status Enabled

Set-AzureTrafficManagerProfile -TrafficManagerProfile $ATMP