﻿## Create new directory (ASM)
New-Item c:\Projects\Websites\AzureWebsiteWithGit -type directory | Set-Location

#Initiate git repository in the created directory
git init .

#Create Azure Website
New-AzureWebsite -Name WebsiteWithGit -Git