﻿## Exporting Web App Metrics to Excel Sheet
#Create object of the Excel.Application
$Excel = New-Object -comobject Excel.Application
#Make this instance visible
$Excel.visible = $True
#Create Excel Workbook
$ExcelWB = $Excel.Workbooks.Add()
$MetricsInfo = Get-AzureWebsiteMetric -Name WebsiteWithGit -StartDate (Get-date).addDays(-7) -MetricNames @("Requests","CpuTime","AverageResponseTime")

ForEach ($Metric in $MetricsInfo)
{
    $Item = 1

    #Create 1 Excel Worksheet
    $ExcelWS = $ExcelWB.Worksheets.Item($Item)
    $ExcelWS.Name = $Metric.Data.Name

    #Define Report Title
    $ExcelWS.Cells.Item(1,1) = $Metric.Data.Name.ToString()
    $ExcelWS.Range("A1","B1").Cells.Merge()
    $ExcelWS.Range("A1","B1").Interior.ColorIndex = 41
    $ExcelWS.Range("A1","B1").Font.ColorIndex = 2
    $ExcelWS.Range("A1","B1").Font.Size = 18
    $ExcelWS.Range("A1","B1").Font.Bold = $True

    $ExcelWS.Cells.Item(2,1) = "Metric Start Date"
    $ExcelWS.Cells.Item(2,2) = $Metric.Data.StartTime

    $ExcelWS.Cells.Item(3,1) = "Metric End Date"
    $ExcelWS.Cells.Item(3,2) = $Metric.Data.EndTime

    $ExcelWS.Cells.Item(4,1) = "Metric Unit"
    $ExcelWS.Cells.Item(4,2) = $Metric.Data.Unit

    #cell background, font color, and boldness of the header
    $ExcelWS.Range("A7","E7").Interior.ColorIndex = 41
    $ExcelWS.Range("A7","E7").Font.ColorIndex = 2
    $ExcelWS.Range("A7","E7").Font.Bold = $True
    
    [reflection.assembly]::loadWithPartialname("Microsoft.Office.Interop.Excel")
    $xlConstants = "microsoft.office.interop.excel.Constants" -as [type]
    $ExcelWS.Range("B8","E10").HorizontalAlignment = $xlConstants::xlCenter

    #Metric Values Table Header
    $ExcelWS.Cells.Item(7,1) = "Time Created"
    $ExcelWS.Cells.Item(7,2) = "Total"
    $ExcelWS.Cells.Item(7,3) = "Minimum"
    $ExcelWS.Cells.Item(7,4) = "Maximum"
    $ExcelWS.Cells.Item(7,5) = "Count"
    $row = 8
    
    ForEach($v in $Metric.Data.Values)
    {
        #Fill the rows with Metric Values information
        $ExcelWS.Cells.Item($row,1) = $v.TimeCreated
        $ExcelWS.Cells.Item($row,2) = $v.Total
        $ExcelWS.Cells.Item($row,3) = $v.Minimum
        $ExcelWS.Cells.Item($row,4) = $v.Maximum
        $ExcelWS.Cells.Item($row,5) = $v.Count
        $row++
    }

    #Table Column Autofit
    $ExcelWS.UsedRange.EntireColumn.AutoFit()
    
    #Create new Excel Worksheet
    $ExcelWB.Worksheets.Add()
    $Item++
}