﻿## Install PsGet module (ASM)
(new-object Net.WebClient).DownloadString("http://psget.net/GetPsGet.ps1") | Invoke-Expression

#Install Posh-Git Module
Install-Module Posh-Git

