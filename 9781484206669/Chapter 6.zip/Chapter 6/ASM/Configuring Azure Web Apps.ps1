﻿#define appSettings in Hashtable
$AppSettings = @{"SiteName" = "Sherif Talaat"; "SiteTitle" = "Sherif Talaat's Blog"}

#Set App Settings
Set-AzureWebsite myWebSite -AppSettings $AppSettings

#Verify App Settings Configuration
(get-AzureWebsite WebsiteWithGit).AppSettings

#Create object of type ConnStringInfo
$ConnStr = New-Object ` Microsoft.WindowsAzure.Commands.Utilities.Websites.Services.WebEntities.ConnStringInfo
#Set Name Property
$ConnStr.Name = "MyWebsiteConnStr"
#Set Connection String Property
$ConnStr.ConnectionString = 'Data Source=tcp:server_name.database.windows.net,1433;InitialCatalog=<DB_NAME>;User Id=<Admin@Server>;Password=<Password>;'

#Set Type Property
$ConnStr.Type = [Microsoft.WindowsAzure.Commands.Utilities.Websites.Services.WebEntities.DatabaseType]::SQLAzure
#Set Connection String
Set-AzureWebsite WebsiteWithGit -ConnectionStrings $ConnStringInfo