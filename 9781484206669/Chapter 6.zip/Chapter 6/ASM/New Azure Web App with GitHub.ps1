﻿## Creating Azure Web Apps with GitHub (ASM)

#Create new directory
New-Item c:\Projects\Websites\AzureWebsiteWithGithub -type directory | Set-Location

#Initiate git repository in the created directory
git init .

#Github Credentials
$Cred = Get-Credential "<GitHub_Username>"

#Create Azure Website
New-AzureWebsite -Name WebsiteWithGithub -Github -GithubCrednetials $Cred