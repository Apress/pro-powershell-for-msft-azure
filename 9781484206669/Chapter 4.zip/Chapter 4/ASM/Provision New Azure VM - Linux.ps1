﻿## Provision New Azure VM – Linux – (ASM)
# SUSE Linux Server 12

$ImageName = "b4590d9e3ed742e4a1d46e5424aa335e__suse-sles-12-v20150213"

New-AzureQuickVM -Linux -Name WebSrv01 -ServiceName "myPublicWebsite" -ImageName $ImageName -Password Microsoft@123 -Linuxuser root -Location "West Europe" -InstanceSize Basic_A1