﻿## Create EndPoint ACL (ASM)

# Create new ACL Config Object
$acl = New-AzureAclConfig

# Set ACL Config - Add Rule
Set-AzureAclConfig -AddRule -ACL $acl -Action Permit -Order 1 -RemoteSubnet "10.10.0.0/8" -Description "On-Premises vLAN"