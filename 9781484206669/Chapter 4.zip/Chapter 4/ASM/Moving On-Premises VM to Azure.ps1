﻿## Moving On-Premises VM to Azure (ASM)

# Get the Azure Storage Account for the default Azure Subscription
$StorageAccountName = (Get-AzureSubscription).CurrentStorageAccount

#S pecify Local VHD file path
$LocalVHD = 'D:\Hyper-V\Virtual Hard Disks\WebSrv01.vhd'

# Specify the URI for the Windows Azure Container
$Destination = 'http://' + $StorageAccountName + '.blob.core.windows.net/vhds/ WebSrv01.vhd'

# Move VHD file from local server to Azure Storage account blob
Add-AzureVhd -LocalFilePath $LocalVHD -Destination $Destination