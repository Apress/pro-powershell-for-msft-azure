﻿#Exporting Azure VMs State
$VMs = Get-AzureVM -ServiceName 'DevTestFarm'

ForEach ($VM in $VMs)
{
    $FileName = $VM.Name + "_VMState.xml"
    Export-AzureVM -ServiceName $VM.ServiceName -Name $VM.Name -Path $home\Desktop\VMs\$FileName
}