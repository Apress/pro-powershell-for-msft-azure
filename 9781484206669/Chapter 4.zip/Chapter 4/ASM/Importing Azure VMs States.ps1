﻿#Importing Azure VMs States

$VMs = Get-ChildItem $home\Desktop\VMs\

ForEach ($VM in $VMs)
{
    Import-AzureVM -Path $VM.Name | New-AzureVM -ServiceName 'ProductionFarm'
}