﻿## Add EndPoint to VM (ASM)

# Create a VM object with the targeted VM config (ASM)
$vmName = "WI-DC-01"
$CloudServiceName = "CloudFarm"
$vm = Get-AzureVM -Name $vmName -ServiceName $CloudServiceName

# Add endPoint and Update the VM
$vm | Add-AzureEndpoint -Name 'HTTPs' -Protocol TCP -LocalPort 443 -PublicPort 443 | Update-AzureVM