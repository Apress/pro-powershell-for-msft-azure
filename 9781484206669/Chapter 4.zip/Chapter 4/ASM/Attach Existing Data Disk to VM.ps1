﻿## Attach an Existing Data Disk to VM (ASM)

# Detach data disk from old VM
Get-AzureVM -Name oldVM -ServiceName CloudFarm | Remove-AzureDataDisk –Lun 2 | Update-AzureVM

# Create a VM object with the targeted VM config
$vmName = "WI-DC-01"
$CloudServiceName = "CloudFarm"
$vm = Get-AzureVM -Name $vmName -ServiceName $CloudServiceName

# Import an existing data disk and Update the VM
$vm | Add-AzureDataDisk -Import -DiskName "myISOsVHD" -LUN 1 | Update-AzureVM