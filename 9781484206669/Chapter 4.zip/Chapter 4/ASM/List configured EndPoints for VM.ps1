﻿## List configured EndPoints for VM (ASM)

# Create a VM object with the targeted VM config
$vm = Get-AzureVM -Name WI-DC-01 -ServiceName CloudFarm

# Retrieve the Endpoints list
$vm | Get-AzureEndpoint | Select Name, Protocol, Port, LocalPort