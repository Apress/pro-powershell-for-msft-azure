﻿## Getting URI of Data Disk Attached to VM (ASM)

$vmName = "WI-DC-01"
$CloudServiceName = "CloudFarm"
$vm = Get-AzureVM -Name $vmName -ServiceName $CloudServiceName

$diskURI = Get-AzureDataDisk –VM $vm | Select MediaLink

$diskURI.MediaLink.OriginalString

