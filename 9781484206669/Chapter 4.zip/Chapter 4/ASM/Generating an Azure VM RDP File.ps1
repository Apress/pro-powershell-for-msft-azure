﻿## Generating an Azure VM RDP File (ASM)
$CloudServiceName = "CloudFarm"

$VMs = Get-AzureVM -ServiceName $CloudServiceName

ForEach ($VM in $VMs)
{
    $FileName = $VM.Name + ".rdp"
    Get-AzureRemoteDesktopFile -ServiceName $VM.ServiceName -Name $VM.Name -LocalPath $home\Desktop\AzureRDPs\$FileName
}