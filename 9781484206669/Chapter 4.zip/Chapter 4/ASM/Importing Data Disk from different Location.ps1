﻿## Importing Data Disk from different Location (ASM)

# Create a VM object with the targeted VM config
$vmName = "WI-DC-01"
$CloudServiceName = "CloudFarm"
$vm = Get-AzureVM -Name $vmName -ServiceName $CloudServiceName

# Import an existing data disk and Update the VM
$DiskLocation = https://mystorage.blob.core.windows.net/Disks/myISOsVHD.vhd

$vm | Add-AzureDataDisk -ImportFrom –MediaLocation –DiskLabel "myISOsVHD" $DiskLocation -LUN 1 | Update-AzureVM