﻿## Attaching Empty Data Disk to VM (ASM)

# Create a VM object with the targeted VM config
$vmName = "WI-DC-01"
$CloudServiceName = "CloudFarm"
$vm = Get-AzureVM -Name $vmName -ServiceName $CloudServiceName

# Attach new data disk and Update the VM
$vm | Add-AzureDataDisk -CreateNew -DiskSizeInGB 50 –DiskLabel "ISOs" -LUN 0 | Update-AzureVM