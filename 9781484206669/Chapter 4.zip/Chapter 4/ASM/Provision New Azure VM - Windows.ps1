﻿## Provision new Azure VM – Windows – (ASM)

# Windows Server 2012 R2, Datacenter Edition
$ImageName = "a699494373c04fc0bc8f2bb1389d6106__Windows-Server-2012-Datacenter-201412.01-en.us-127GB.vhd"

New-AzureQuickVM -Windows -Name WebSrv01 -ServiceName "myPublicWebsite" -ImageName $ImageName -Password Microsoft@123 -AdminUsername SherifT -Location "West Europe" -InstanceSize Basic_A1