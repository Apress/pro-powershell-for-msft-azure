﻿## Creating VM Image from VHD (ASM)

#Specify Local VHD file path
$LocalVHD = 'D:\Hyper-V\Virtual Hard Disks\WebSrv01.vhd'

#Specify the URI for the Windows Azure Container
$Destination = 'http://' + $StorageAccountName + '.blob.core.windows.net/vhds/ WebSrv01.vhd'

#Move VHD file from local server to Azure Storage account blob
Add-AzureVhd -LocalFilePath $LocalVHD -Destination $Destination

#Build VM image using vhd
Add-AzureVMImage -ImageName WebSrvImage -Label "Corp Web Server Image" -OS Windows -MediaLocation $Destination -PublishedDate (Get-Date)