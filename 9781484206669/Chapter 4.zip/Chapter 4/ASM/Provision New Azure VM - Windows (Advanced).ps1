﻿## Provision New Azure VM - Windows (Advanced) - (ASM)

# Windows Server 2012 R2, Datacenter Edition
$ImageName = "a699494373c04fc0bc8f2bb1389d6106__Windows-Server-2012-Datacenter-201412.01-en.us-127GB.vhd"

# Create VM Config Object and Provisioning Config
$vm1 = New-AzureVMConfig -Name WebSrv01 -InstanceSize Basic_A1 -ImageName $ImageName
$vm1 | `
Add-AzureProvisioningConfig -AdminUsername "SherifT" `
–Password "P@ssw0rd" `
-WindowsDomain `
–Domain "Corp" `
–JoinDomain "Corp.local" `
–DomainUserName "Administrator" `
–DomainPassword "P@ssw0rd" ` 
-MachineObjectOU "OU=AzureVMs,DC=Corp,DC=local" `
-DisableAutomaticUpdates -TimeZone "Pacific Standard Time"

# Create Azure VM using the previously created config object
New-AzureVM -ServiceName "myPublicWebsite" -VMs $vm1