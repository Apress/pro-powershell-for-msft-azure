﻿## Configure NLB EndPoints (ASM)

# Get all VMs within Cloud Service
$CloudServiceName = "CloudFarm"
$VMs = Get-AzureVM -ServiceName $CloudServiceName

# Adding Load-Balanced Azure Endpoint to $VMs
$VMs | Add-AzureEndpoint -Name "LB-Http" -Protocol tcp -PublicPort 80 -LocalPort 80 -LBSetName "LB-WebFarm" -ProbePort 80 -ProbeProtocol "http" -ProbePath "/" | Update-AzureVM