﻿##Managing HDInsight Cluster##
#Retrieve cluster info
Get-AzureHDInsightCluster -Name pshdclstr
#Remove cluster
Remove-AzureHDInsightCluster -Name pshdclstr2