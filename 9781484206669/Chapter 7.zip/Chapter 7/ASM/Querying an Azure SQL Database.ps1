﻿# Azure SQL Database Connectin String
$ConStr = "Server=tcp:s5m8t9ssp5.database.windows.net,1433;Database=DemoDB;User ID=SherifT@s5m8t9ssp5;Password=pass@word1;Trusted_Connection=False;"

# Create and open SQL Connection
$SQLConnection = New-Object System.Data.SqlClient.SqlConnection;
$SQLConnection.ConnectionString = $ConStr;
$SQLConnection.Open();

# Create New Table using T-SQL Query
$Query = "Create table Services ( id int not null primary key, servicename varchar(50) )"
$command = $SQLConnection.CreateCommand()
$command.CommandText = $Query
$command.ExecuteNonQuery()

# Insert data to SQL Database Table
$InsertSQL = "insert into Services values(1, 'Database');
insert into Services values(2, 'Storage');
insert into Services values(3, 'Compute'); insert into Services values(4, 'HDInisght');
insert into Services values(5, 'Stream analytics');"

$command = $SQLConnection.CreateCommand()
$command.CommandText = $InsertSQL
$command.ExecuteNonQuery()

# Query Data from Azure SQL Database Table
$SelectSQL = "Select id, servicename from Services;"
$SelectCommand = $SQLConnection.CreateCommand()
$SelectCommand.CommandText = $SelectSQL
$results = $SelectCommand.ExecuteReader()

# Reformatting Quert output
$results = $SelectCommand.ExecuteReader()
For($i = 0; $i -le 9 ; $i = $i+2)
{
    $indic = $results.Read()
    $results[0].ToString() + " " + $results[1]
}


