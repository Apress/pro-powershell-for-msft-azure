﻿
# Creating PSCredential Object
$Username = "SherifT"
$Password = "pass@word1" | ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential($Username,$Password)
$AzureDatabaseServer = "SERVERNAME"

# Creating Connection Context (ASM)
$sqlContext = New-AzureSqlDatabaseServerContext -ServerName $AzureDatabaseServer -Credential $Cred

# Create Azure Storage Context (ASM)
$StorageName = "mylabstroageaccount"
$StorageAccessKey = Get-AzureStorageKey -StorageAccountName $StorageAccountName | Select-ExpandProperty Primary
$StorageCtx = New-AzureStorageContext -StorageAccountName $StorageName -StorageAccountKey $StorageAccessKey

# Get Storage Container Information (ASM)
$Container = Get-AzureStorageContainer -Name "demodbbackup" -Context $StorageCtx

# Importing Azure SQL Database (ASM)
$importRequest = Start-AzureSqlDatabaseImport -SqlConnectionContext $sqlContext -StorageContainer $Container -DatabaseName "demodb" -BlobName "demodbexport"

# Tracking Azure Database Export Status (ASM)
Get-AzureSqlDatabaseImportExportStatus –Request $importRequest