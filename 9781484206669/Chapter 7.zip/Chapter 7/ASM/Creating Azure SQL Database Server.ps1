﻿## Creating Azure SQL Database Server (ASM)
$AzureDatabaseServer = New-AzureSqlDatabaseServer -AdministratorLogin "SherifT" -AdministratorLoginPassword "pass@word1" -Location "West US" -Version "12.0" –verbose

$AzureDatabaseServer | fl