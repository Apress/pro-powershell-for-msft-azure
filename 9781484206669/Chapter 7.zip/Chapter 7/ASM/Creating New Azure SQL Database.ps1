﻿## Creating New Azure Database (ASM)

# Ceating Service Objective Object
$so = Get-AzureSqlDatabaseServiceObjective -ServerName $AzureDatabaseServer.ServerName -ServiceObjectiveName S2

# Creating Azure SQL Database
New-AzureSqlDatabase -ServerName $AzureDatabaseServer.ServerName -DatabaseName DemoDB -Edition "Standard" –MaxSizeGB 50 -ServiceObjective $so