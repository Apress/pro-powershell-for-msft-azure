﻿## Creating New Azure SQL Database Server Firewall Rule (ASM)
$AzureDatabaseServer = Get-AzureSqlServer –ServerName "SERVERNAME"

# Create Firewall Rule for single IP Address
New-AzureSqlDatabaseServerFirewallRule -ServerName $AzureDatabaseServer.ServerName -RuleName "myHomeComputer" -StartIpAddress "167.200.188.210" -EndIpAddress "167.200.188.210"

# Create Firewall Rule for Azure Services
New-AzureSqlDatabaseServerFirewallRule -ServerName $AzureDatabaseServer.ServerName -RuleName "AllowAzureServices" –AllowAllAzureServices